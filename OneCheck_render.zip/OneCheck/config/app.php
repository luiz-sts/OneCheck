<?php
declare(strict_types=1);
return [
    'base_path' => '',
    'name'      => 'OneCheck',
];
